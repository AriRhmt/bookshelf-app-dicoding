
document.addEventListener("DOMContentLoaded", function () {
  let books = [];
  const STORAGE_KEY = "BOOKSHELF_APPS";

  const inputForm = document.getElementById("inputBook");
  const incompleteBookshelfList = document.getElementById("incompleteBookshelfList");
  const completeBookshelfList = document.getElementById("completeBookshelfList");
  const searchForm = document.getElementById("searchBook");
  const searchInput = document.getElementById("searchBookTitle");
  const editModal = document.getElementById("editModal");
  const editForm = document.getElementById("editBookForm");
  const cancelEditBtn = document.getElementById("cancelEdit");

  function isStorageExist() {
    return typeof Storage !== "undefined";
  }

  function saveData() {
    if (isStorageExist()) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(books));
    }
  }

  function loadDataFromStorage() {
    const serializedData = localStorage.getItem(STORAGE_KEY);
    if (serializedData) {
      books = JSON.parse(serializedData);
    }
    renderBooks();
  }

  function generateBookObject(id, title, author, year, isComplete) {
    return { id, title, author, year, isComplete };
  }

  function makeBook(bookObject) {
    const bookContainer = document.createElement("div");
    bookContainer.setAttribute("data-bookid", bookObject.id);
    bookContainer.setAttribute("data-testid", "bookItem");

    const bookTitle = document.createElement("h3");
    bookTitle.innerText = bookObject.title;
    bookTitle.setAttribute("data-testid", "bookItemTitle");

    const bookAuthor = document.createElement("p");
    bookAuthor.innerText = `Penulis: ${bookObject.author}`;
    bookAuthor.setAttribute("data-testid", "bookItemAuthor");

    const bookYear = document.createElement("p");
    bookYear.innerText = `Tahun: ${bookObject.year}`;
    bookYear.setAttribute("data-testid", "bookItemYear");

    const actionContainer = document.createElement("div");

    const toggleButton = document.createElement("button");
    toggleButton.innerText = bookObject.isComplete ? "Belum selesai dibaca" : "Selesai dibaca";
    toggleButton.setAttribute("data-testid", "bookItemIsCompleteButton");
    toggleButton.addEventListener("click", function () {
      toggleBookStatus(bookObject.id);
    });

    const deleteButton = document.createElement("button");
    deleteButton.innerText = "Hapus buku";
    deleteButton.setAttribute("data-testid", "bookItemDeleteButton");
    deleteButton.addEventListener("click", function () {
      removeBook(bookObject.id);
    });

    const editButton = document.createElement("button");
    editButton.innerText = "Edit buku";
    editButton.setAttribute("data-testid", "bookItemEditButton");
    editButton.addEventListener("click", function () {
      openEditModal(bookObject);
    });

    actionContainer.appendChild(toggleButton);
    actionContainer.appendChild(deleteButton);
    actionContainer.appendChild(editButton);

    bookContainer.appendChild(bookTitle);
    bookContainer.appendChild(bookAuthor);
    bookContainer.appendChild(bookYear);
    bookContainer.appendChild(actionContainer);

    return bookContainer;
  }

  function renderBooks(filter = "") {
    incompleteBookshelfList.innerHTML = "";
    completeBookshelfList.innerHTML = "";
    for (const book of books) {
      if (book.title.toLowerCase().includes(filter.toLowerCase())) {
        const bookElement = makeBook(book);
        if (book.isComplete) {
          completeBookshelfList.appendChild(bookElement);
        } else {
          incompleteBookshelfList.appendChild(bookElement);
        }
      }
    }
  }

  function addBook(title, author, year, isComplete) {
    const id = +new Date();
    const newBook = generateBookObject(id, title, author, year, isComplete);
    books.push(newBook);
    saveData();
    renderBooks();
  }

  function toggleBookStatus(bookId) {
    const book = books.find(b => b.id === bookId);
    if (book) {
      book.isComplete = !book.isComplete;
      saveData();
      renderBooks();
    }
  }

  function removeBook(bookId) {
    books = books.filter(b => b.id !== bookId);
    saveData();
    renderBooks();
  }

  function openEditModal(book) {
    document.getElementById("editBookId").value = book.id;
    document.getElementById("editBookTitle").value = book.title;
    document.getElementById("editBookAuthor").value = book.author;
    document.getElementById("editBookYear").value = book.year;
    editModal.style.display = "block";
  }

  function closeEditModal() {
    editModal.style.display = "none";
    editForm.reset();
  }

  function updateBook(id, title, author, year) {
    const book = books.find(b => b.id === parseInt(id));
    if (book) {
      book.title = title;
      book.author = author;
      book.year = parseInt(year);
      saveData();
      renderBooks();
    }
  }

  inputForm.addEventListener("submit", function (e) {
    e.preventDefault();
    const title = document.getElementById("inputBookTitle").value;
    const author = document.getElementById("inputBookAuthor").value;
    const year = parseInt(document.getElementById("inputBookYear").value);
    const isComplete = document.getElementById("inputBookIsComplete").checked;

    addBook(title, author, year, isComplete);
    inputForm.reset();
  });

  searchForm.addEventListener("submit", function (e) {
    e.preventDefault();
    renderBooks(searchInput.value);
  });

  editForm.addEventListener("submit", function (e) {
    e.preventDefault();
    const id = document.getElementById("editBookId").value;
    const title = document.getElementById("editBookTitle").value;
    const author = document.getElementById("editBookAuthor").value;
    const year = document.getElementById("editBookYear").value;
    updateBook(id, title, author, year);
    closeEditModal();
  });

  cancelEditBtn.addEventListener("click", closeEditModal);

  loadDataFromStorage();
});
